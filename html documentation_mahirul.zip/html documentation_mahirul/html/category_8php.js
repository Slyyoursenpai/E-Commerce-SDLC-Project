var category_8php =
[
    [ "$category", "category_8php.html#a18b2a8d133fa7733bf34abcc6ca2ef5b", null ],
    [ "$select_products", "category_8php.html#acec19760e0f0e8b18a7e288278cfa160", null ],
    [ "else", "category_8php.html#ad04bd0017ef5e948d88681497c568db4", null ]
];