var home__model_8php =
[
    [ "$select_products", "home__model_8php.html#acec19760e0f0e8b18a7e288278cfa160", null ],
    [ "else", "home__model_8php.html#a684ba8e147df98fd2f7ea2c315d1c8e9", null ]
];