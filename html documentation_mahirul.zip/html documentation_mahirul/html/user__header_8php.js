var user__header_8php =
[
    [ "$count_cart_items", "user__header_8php.html#a837c09b9421e6f6398d800108878767e", null ],
    [ "$count_wishlist_items", "user__header_8php.html#a5a718c409252cf48a3d876d21a9b407b", null ],
    [ "$select_profile", "user__header_8php.html#a4634919ea66f59f973d888221a82d91c", null ],
    [ "$total_cart_counts", "user__header_8php.html#a5a6a6b2d2cf139246b6cb8c54dd47ce2", null ],
    [ "$total_wishlist_counts", "user__header_8php.html#a021f692cbffd94c8d39a48da5b87bccd", null ]
];