var searchData=
[
  ['home_5fcontroller_2ephp_0',['home_controller.php',['../home__controller_8php.html',1,'']]],
  ['home_5fmodel_2ephp_1',['home_model.php',['../home__model_8php.html',1,'']]],
  ['home_5fview_2ephp_2',['home_view.php',['../home__view_8php.html',1,'']]]
];
