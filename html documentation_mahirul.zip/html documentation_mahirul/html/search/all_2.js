var searchData=
[
  ['category_2ephp_0',['category.php',['../category_8php.html',1,'']]],
  ['category_5fcontroller_2ephp_1',['category_controller.php',['../category__controller_8php.html',1,'']]],
  ['category_5fmodel_2ephp_2',['category_model.php',['../category__model_8php.html',1,'']]],
  ['category_5fview_2ephp_3',['category_view.php',['../category__view_8php.html',1,'']]],
  ['connect_2ephp_4',['connect.php',['../connect_8php.html',1,'']]]
];
