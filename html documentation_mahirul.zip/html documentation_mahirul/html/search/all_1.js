var searchData=
[
  ['admin_5fheader_2ephp_0',['admin_header.php',['../admin__header_8php.html',1,'']]],
  ['admin_5flogout_2ephp_1',['admin_logout.php',['../admin__logout_8php.html',1,'']]]
];
