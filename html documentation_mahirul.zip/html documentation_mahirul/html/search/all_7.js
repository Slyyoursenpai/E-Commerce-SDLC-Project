var searchData=
[
  ['search_5fhandler_5fmodel_2ephp_0',['search_handler_model.php',['../search__handler__model_8php.html',1,'']]],
  ['search_5fpage_5fview_2ephp_1',['search_page_view.php',['../search__page__view_8php.html',1,'']]]
];
