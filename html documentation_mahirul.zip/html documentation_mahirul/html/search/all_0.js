var searchData=
[
  ['_24category_0',['$category',['../category_8php.html#a18b2a8d133fa7733bf34abcc6ca2ef5b',1,'$category:&#160;category.php'],['../category__model_8php.html#a18b2a8d133fa7733bf34abcc6ca2ef5b',1,'$category:&#160;category_model.php'],['../category__view_8php.html#a18b2a8d133fa7733bf34abcc6ca2ef5b',1,'$category:&#160;category_view.php']]],
  ['_24connect_1',['$connect',['../connect_8php.html#a956617395b85e98d907df712f6d0d3f7',1,'connect.php']]],
  ['_24count_5fcart_5fitems_2',['$count_cart_items',['../user__header_8php.html#a837c09b9421e6f6398d800108878767e',1,'user_header.php']]],
  ['_24count_5fwishlist_5fitems_3',['$count_wishlist_items',['../user__header_8php.html#a5a718c409252cf48a3d876d21a9b407b',1,'user_header.php']]],
  ['_24db_5fname_4',['$db_name',['../connect_8php.html#a26dcb19f4431598ddd5f58147f131bee',1,'connect.php']]],
  ['_24fetch_5fproducts_5',['$fetch_products',['../category__model_8php.html#a847acb8aef1e1be641c748257ed39943',1,'category_model.php']]],
  ['_24fetch_5fprofile_6',['$fetch_profile',['../admin__header_8php.html#a1f3d88d0f379d8bbdff7a45269abdd3d',1,'admin_header.php']]],
  ['_24pid_7',['$pid',['../quick__view_8php.html#a9b726f748a2135350f7d86668cc058ee',1,'$pid:&#160;quick_view.php'],['../quick__view__model_8php.html#a9b726f748a2135350f7d86668cc058ee',1,'$pid:&#160;quick_view_model.php']]],
  ['_24select_5fproducts_8',['$select_products',['../category_8php.html#acec19760e0f0e8b18a7e288278cfa160',1,'$select_products:&#160;category.php'],['../category__model_8php.html#acec19760e0f0e8b18a7e288278cfa160',1,'$select_products:&#160;category_model.php'],['../home__model_8php.html#acec19760e0f0e8b18a7e288278cfa160',1,'$select_products:&#160;home_model.php'],['../quick__view_8php.html#acec19760e0f0e8b18a7e288278cfa160',1,'$select_products:&#160;quick_view.php'],['../quick__view__model_8php.html#acec19760e0f0e8b18a7e288278cfa160',1,'$select_products:&#160;quick_view_model.php']]],
  ['_24select_5fprofile_9',['$select_profile',['../admin__header_8php.html#a9471051c7cd544dc58d83317ce5f8ecc',1,'$select_profile:&#160;admin_header.php'],['../user__header_8php.html#a4634919ea66f59f973d888221a82d91c',1,'$select_profile:&#160;user_header.php']]],
  ['_24total_5fcart_5fcounts_10',['$total_cart_counts',['../user__header_8php.html#a5a6a6b2d2cf139246b6cb8c54dd47ce2',1,'user_header.php']]],
  ['_24total_5fwishlist_5fcounts_11',['$total_wishlist_counts',['../user__header_8php.html#a021f692cbffd94c8d39a48da5b87bccd',1,'user_header.php']]],
  ['_24user_5fname_12',['$user_name',['../connect_8php.html#a768c773a5f9a6258343b30f3205f528f',1,'connect.php']]],
  ['_24user_5fpassword_13',['$user_password',['../connect_8php.html#a280b458df1d1e72d65eeab2149573a8e',1,'connect.php']]]
];
