var files_dup =
[
    [ "category", "dir_726dcb61e6d240cc0086922c8e47f555.html", "dir_726dcb61e6d240cc0086922c8e47f555" ],
    [ "components", "dir_409f97388efe006bc3438b95e9edef48.html", "dir_409f97388efe006bc3438b95e9edef48" ],
    [ "quick_view", "dir_b0bb0817cc619239f181fac4497bd802.html", "dir_b0bb0817cc619239f181fac4497bd802" ],
    [ "search", "dir_19b2bf9199a15c634a08b1ede1dd896a.html", "dir_19b2bf9199a15c634a08b1ede1dd896a" ],
    [ "home_controller.php", "home__controller_8php.html", "home__controller_8php" ],
    [ "home_model.php", "home__model_8php.html", "home__model_8php" ],
    [ "home_view.php", "home__view_8php.html", null ]
];