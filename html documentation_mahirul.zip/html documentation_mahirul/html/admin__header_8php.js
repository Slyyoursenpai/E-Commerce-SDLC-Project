var admin__header_8php =
[
    [ "$fetch_profile", "admin__header_8php.html#a1f3d88d0f379d8bbdff7a45269abdd3d", null ],
    [ "$select_profile", "admin__header_8php.html#a9471051c7cd544dc58d83317ce5f8ecc", null ]
];