var connect_8php =
[
    [ "$connect", "connect_8php.html#a956617395b85e98d907df712f6d0d3f7", null ],
    [ "$db_name", "connect_8php.html#a26dcb19f4431598ddd5f58147f131bee", null ],
    [ "$user_name", "connect_8php.html#a768c773a5f9a6258343b30f3205f528f", null ],
    [ "$user_password", "connect_8php.html#a280b458df1d1e72d65eeab2149573a8e", null ]
];