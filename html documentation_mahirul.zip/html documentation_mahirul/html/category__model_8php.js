var category__model_8php =
[
    [ "$category", "category__model_8php.html#a18b2a8d133fa7733bf34abcc6ca2ef5b", null ],
    [ "$fetch_products", "category__model_8php.html#a847acb8aef1e1be641c748257ed39943", null ],
    [ "$select_products", "category__model_8php.html#acec19760e0f0e8b18a7e288278cfa160", null ],
    [ "else", "category__model_8php.html#a684ba8e147df98fd2f7ea2c315d1c8e9", null ]
];